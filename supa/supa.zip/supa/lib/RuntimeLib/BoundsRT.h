/*
 * BoundsRT.h
 *
 *  Created on: Jun 6, 2013
 *      Author: yusui
 */

#ifndef BOUNDSRT_H_
#define BOUNDSRT_H_

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

#define __WEAK__ __attribute__((__weak__))

#define __WEAK_INLINE __attribute__((__weak__,__always_inline__))


#endif /* BOUNDSRT */
