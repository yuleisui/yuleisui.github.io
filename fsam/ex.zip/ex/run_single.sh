#-addTDEdge=0 : single thread analysis
#-addTDEdge=1 : non-sparse analysis
#-addTDEdge=2 : FSAM analysis

mta -print-pts -incdata=true -addTDEdge=2 $1 

